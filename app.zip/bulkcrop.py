from PIL import Image
import os, sys


def bulkcrop(path,**kwargs):
    os.chdir(path)
    #print('getting Inside this')
    for item in os.listdir(path):
     #   print('getting inside for ',item)
      #  print(os.path)
        if os.path.isfile(item):
       #     print('getting inside if ')
            im = Image.open(item)
            width, height = im.size
        #    print(width,height)
         #   print(kwargs)
          #  print('percent' in kwargs)
            if 'percent' in kwargs:
                #print('Cropping with user defined percentage')
                left = (width -width *(kwargs['percent']/100))/2
                top = (height-height *(kwargs['percent']/100))/2
                right = width-left
                bottom = height-top
                # Setting the points for cropped image 
#                 left = int(width/4)
#                 top = int(height  * (kwargs['percent']/100))
#                 right = int(width * 3/4)
#                 bottom = int(height  * (kwargs['percent']/100))
                
            elif 'image_width' in kwargs and 'image_height' in kwargs and kwargs['image_width']<=width and kwargs['image_height'] <=height:
                left = (width - kwargs['image_width'])/2
                top = (height - kwargs['image_height'])/2
                right = width-left
                bottom = height-top
            else:
                raise ValueError('Looks like you have either not given all required fields or given size exceeds original image size')
                
            f, _ = os.path.splitext(item)
            imResize = im.crop((left, top, right, bottom)) 
            imResize.save(f + ' resized.jpg', 'JPEG', quality=90)

if __name__ == '__main__':
    print('Executing main')
    path = ('C:\\Users\\nihar\\Downloads\\session11_pics')
    bulkcrop(path,image_width=5000,image_height=5000)