from PIL import Image
import os

def jpg2png_func(dir,img):
   print('Executing JPG to PNG Module') 
   print("======",dir)
   os.chdir(dir)
   print("-------------",os.curdir)
   im = Image.open(dir+ '\\' +  img + '.jpg')
   im.save(dir+ '\\' + img + '.png')

if __name__ == '__main__':
    dir = 'C:\\Users\\nihar\\Downloads\\session11_pics'
    img= 'image1'
    jpg2png_func(dir,img)
