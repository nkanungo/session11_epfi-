from PIL import Image
import os

def png2jpg_func(dir,img):
   
   print('Executing PNG to JPG Module') 
   print("======",dir)
   os.chdir(dir)
   print("-------------",os.curdir)
   im = Image.open(dir+ '\\' +  img + '.png')
   im.save(dir+ '\\' + img + '.jpg')

  

if __name__ == '__main__':
    dir = 'C:\\Users\\nihar\\Downloads\\session11_pics'
    img= 'image10'
    png2jpg_func(dir,img)
