from PIL import Image
import os, sys

def resize(path,**kwargs):
    os.chdir(path)
    for item in os.listdir(path):
        if os.path.isfile(item):
            im = Image.open(item)
            width, height = im.size
            if 'percent' in kwargs and bool(kwargs['percent']):
                width  = int(width  * (kwargs['percent']/100))
                height = int(height * (kwargs['percent']/100))
            elif 'width' in kwargs:
                width  = kwargs['width']  
            elif 'height' in kwargs:
                height = kwargs['height']            
                
            f, e = os.path.splitext(item)
            imResize = im.resize((width,height), Image.ANTIALIAS)
            imResize.save(f + ' resized.jpg', 'JPEG', quality=90)

if __name__ == '__main__':
    path = ('C:\\Users\\nihar\\Downloads\\session11_pics')
    resize(path)